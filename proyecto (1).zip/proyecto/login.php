<?php
session_start();
if (isset($_POST['login'])) {
    include("conexion.php");
    $user = $_POST['usuario'];
    $pass = $_POST['password'];

    $sql = "SELECT * FROM usuarios WHERE usuario = '$user' AND password = '$pass'";
    $resultado = $conexion->query($sql);

    if ($resultado->num_rows > 0) {
        $_SESSION['usuario'] = $user;
        header("Location: proyecto.php");
        exit();
    } else {
        $error = "Usuario o contraseña incorrectos";
    }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login | Botanas Islas</title>
    <link rel="stylesheet" href="estilos.css">
</head>
<body style="display: flex; justify-content: center; align-items: center; height: 100vh;">

<div class="inventario" style="width: 320px; padding: 25px;">
    <h2>Iniciar Sesión</h2>
    <p style="margin-bottom: 15px;">Botanas Islas</p>
    
    <?php if(isset($error)) echo "<p style='color: red; margin-bottom: 10px;'>$error</p>"; ?>
    
    <form method="POST" class="busqueda" style="display: flex; flex-direction: column; gap: 10px;">
        <label>Usuario</label>
        <input type="text" name="usuario" required>
        
        <label>Contraseña</label>
        <input type="password" name="password" required>
        
        <button type="submit" name="login" class="btn-principal" style="margin-top: 10px;">Entrar</button>
    </form>
</div>

</body>
</html>